import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoanApplyDTO } from 'src/app/model/loan-apply-dto';
import { LoanserviceService } from 'src/app/service/loanservice.service';

@Component({
  selector: 'app-manageloan',
  templateUrl: './manageloan.component.html',
  styleUrls: ['./manageloan.component.css']
})
export class ManageloanComponent {
constructor(private loanService: LoanserviceService,private router: Router){}

loan:LoanApplyDTO[] = [];

ngOninit(): void{
this.getAllLoan();
}

getAllLoan(){
  this.loanService.getAllAppliedLoan().subscribe(
    (list) => {
      this.loan = list;
      console.log(list);
    },
  );
  
}

approve(loanDetail:LoanApplyDTO){

  const currentDate = new Date();

loanDetail.loanOrginationDate = new Date();
  loanDetail.loanStatus="APPROVE";


this.loanService.updateByLoanNo(loanDetail);



}
reject(loanDetail:LoanApplyDTO){
  
  loanDetail.loanOrginationDate = new Date();  
loanDetail.loanStatus="REJECT";

  this.loanService.updateByLoanNo(loanDetail);
}


}
