import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoanApplyDTO } from 'src/app/model/loan-apply-dto';
import { LoaninformationService } from 'src/app/service/loaninformation.service';
import { LoanserviceService } from 'src/app/service/loanservice.service';
@Component({
  selector: 'app-applyloan',
  templateUrl: './applyloan.component.html',
  styleUrls: ['./applyloan.component.css']
})
export class ApplyloanComponent {

  loanNo!:number;
  constructor(private loanDetail: LoanserviceService,private router: Router) {}

  submitForm(data:LoanApplyDTO) {
     this.loanDetail.createLoan(data)
      .subscribe((response)=> {
        console.log('Response from backend:', response);
        this.loanNo = response.loanNo;
        
      });
    }
      goBack ()
      {
        this.router.navigate(['/user-dashboard']); 
      }  

}
