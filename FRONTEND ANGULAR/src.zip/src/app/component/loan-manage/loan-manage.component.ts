import { Component } from '@angular/core';

@Component({
  selector: 'app-loan-manage',
  templateUrl: './loan-manage.component.html',
  styleUrls: ['./loan-manage.component.css']
})
export class LoanManageComponent {

}
