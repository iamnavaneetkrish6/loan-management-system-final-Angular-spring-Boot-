export class CustomerAccountDTO {
    accountDetailsId!:number;
    name!:string;
    accountNumber!:number;
    bankName!:string;
    panCardNumber!:string;
    aadharNumber!:number;
}
