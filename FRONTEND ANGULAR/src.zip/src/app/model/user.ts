export class User {
    firstname:any="";
    lastname:any="";
    email:any="";
    password:any="";
    
}
