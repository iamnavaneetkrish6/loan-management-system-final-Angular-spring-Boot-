export class AdminDTO {

    adminId!:number;
    adminName!:string;
    emailId!:string;
    adminUsername!:string;
    password!:string;
    roles!:string;
}
