export class LoanApplyDTO {

    loanNo!:number;
    loanTypeName!:number;
    loanAmount!:number;
    loanOrginationDate!:Date;
    propertyAddress!:string;
    customerName!:string;
    loanStatus!:string;
}
