export class CustomerDetailDTO {

    customerId!:number;
    customerName!:string;
    customerUsername!:string;
    customerPassword!:string;
    customerAddress!:string;
    customerState!:string;
    customerCountry!:string;
    customerEmailId!:string;
    roles!:string;
}
