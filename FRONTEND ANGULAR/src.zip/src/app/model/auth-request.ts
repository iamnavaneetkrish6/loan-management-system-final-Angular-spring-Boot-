export class AuthRequest {
    username!:string ;
    password!:string ;

}
