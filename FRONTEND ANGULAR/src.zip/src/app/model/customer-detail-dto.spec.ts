import { CustomerDetailDTO } from './customer-detail-dto';

describe('CustomerDetailDTO', () => {
  it('should create an instance', () => {
    expect(new CustomerDetailDTO()).toBeTruthy();
  });
});
