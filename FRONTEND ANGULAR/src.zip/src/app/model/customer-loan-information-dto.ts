export class CustomerLoanInformationDTO {

    loanInformationId!:number;
    loanNumber!:number;
    customerName!:string;
    loanAmount!:number;
    loanOrginationDate!:Date;
    loanStatus!:string;
}
