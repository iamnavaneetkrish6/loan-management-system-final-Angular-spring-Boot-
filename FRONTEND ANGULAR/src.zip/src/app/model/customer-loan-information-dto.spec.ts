import { CustomerLoanInformationDTO } from './customer-loan-information-dto';

describe('CustomerLoanInformationDTO', () => {
  it('should create an instance', () => {
    expect(new CustomerLoanInformationDTO()).toBeTruthy();
  });
});
