export class LoanTypeDTO {

    loanTypeId!:number;
    loanTypeName!:string;
    loanInterestRate!:number;
    loanTerm!:number;
    loanDescription!:string;
    loanManagementFees!:number;
}
