import { LoanTypeDTO } from './loan-type-dto';

describe('LoanTypeDTO', () => {
  it('should create an instance', () => {
    expect(new LoanTypeDTO()).toBeTruthy();
  });
});
