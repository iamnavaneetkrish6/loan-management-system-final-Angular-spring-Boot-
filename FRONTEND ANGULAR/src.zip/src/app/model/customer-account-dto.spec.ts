import { CustomerAccountDTO } from './customer-account-dto';

describe('CustomerAccountDTO', () => {
  it('should create an instance', () => {
    expect(new CustomerAccountDTO()).toBeTruthy();
  });
});
