import { PropertyDetailDTO } from './property-detail-dto';

describe('PropertyDetailDTO', () => {
  it('should create an instance', () => {
    expect(new PropertyDetailDTO()).toBeTruthy();
  });
});
