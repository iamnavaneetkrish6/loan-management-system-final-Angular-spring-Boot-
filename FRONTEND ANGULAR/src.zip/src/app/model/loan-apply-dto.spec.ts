import { LoanApplyDTO } from './loan-apply-dto';

describe('LoanApplyDTO', () => {
  it('should create an instance', () => {
    expect(new LoanApplyDTO()).toBeTruthy();
  });
});
