export class PropertyDetailDTO {

    propertyId!:number;
    propertyOwner!:string;
    propertyAddress!:string;
    propertyValue!:number;

}
