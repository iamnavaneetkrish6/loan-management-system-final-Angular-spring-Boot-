import { AdminDTO } from './admin-dto';

describe('AdminDTO', () => {
  it('should create an instance', () => {
    expect(new AdminDTO()).toBeTruthy();
  });
});
